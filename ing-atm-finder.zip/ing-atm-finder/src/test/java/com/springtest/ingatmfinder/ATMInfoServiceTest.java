/*
package com.springtest.ingatmfinder;

import com.springtest.ingatmfinder.model.ATMInfo;
import com.springtest.ingatmfinder.model.Address;
import com.springtest.ingatmfinder.model.GeoLocation;
import com.springtest.ingatmfinder.services.ATMInfoService;
import com.springtest.ingatmfinder.utils.FileUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class ATMInfoServiceTest {

    @MockBean
    FileUtility fileUtility;

    public void setup(){
        fileUtility = Mockito.mock(FileUtility.class);
    }

    @Test
    public void test_getATMInfoForCity_Positive() {
        // prepare
        ATMInfoService atmInfoService = new ATMInfoService(fileUtility);
        List<ATMInfo> ATMs = new ArrayList<>();
        ATMs.add(
                new ATMInfo(
                        new Address("1", "123", "postalcode", "city", new GeoLocation("lat", "lng")),
                        1L,
                        "Type"));

        // act
        Mockito.doNothing().when(fileUtility.writeContentToFile(Mockito.<String>anyString(), Mockito.<InputStream>any()));
        List<ATMInfo> resulList = atmInfoService.getATMInfoForCity("AnyCity");

        // assert
        Assertions.assertEquals(true, !resulList.isEmpty());
    }


}
*/
