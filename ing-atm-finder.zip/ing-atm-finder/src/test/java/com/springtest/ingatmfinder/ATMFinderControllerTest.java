/*
package com.springtest.ingatmfinder;

import com.springtest.ingatmfinder.controller.ATMFinderController;
import com.springtest.ingatmfinder.services.ATMInfoService;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;

@RunWith(MockitoJUnitRunner.class)
public class ATMFinderControllerTest {

    // Dependencies will be mocked
    @Mock
    ATMInfoService atmInfoService;

    // Class to be tested
    @InjectMocks
    ATMFinderController atmFinderController;

    @Before
    public void setUp() {
        atmFinderController = new ATMFinderController(atmInfoService);
        atmInfoService = Mockito.mock(ATMInfoService.class);
    }

    @Test
    public void test_ATMsForCityHeilooExist() {
        // act
        Mockito.when(atmInfoService.getATMInfoForCity(Mockito.<String>anyString())).thenReturn(new ArrayList<>());
        atmFinderController.getATMsForCity("as");

        // assert
    }
}
*/
