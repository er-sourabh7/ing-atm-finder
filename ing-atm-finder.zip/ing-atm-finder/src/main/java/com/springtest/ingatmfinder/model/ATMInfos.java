package com.springtest.ingatmfinder.model;

import java.util.List;

public class ATMInfos {

    private List<ATMInfo> atmInfoList;

    public ATMInfos(List<ATMInfo> atmInfoList) {
        this.atmInfoList = atmInfoList;
    }

    public List<ATMInfo> getAtmInfoList() {
        return atmInfoList;
    }

    public void setAtmInfoList(List<ATMInfo> atmInfoList) {
        this.atmInfoList = atmInfoList;
    }
}
