package com.springtest.ingatmfinder.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ATMInfo {

    private Address address;
    private Long distance;
    private String type;
    private List<String> functionality;

    public ATMInfo() {
    }

    public ATMInfo(Address address, Long distance, String type) {
        this.address = address;
        this.distance = distance;
        this.type = type;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("distance")
    public Long getDistance() {
        return distance;
    }

    public void setDistance(Long distance) {
        this.distance = distance;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("functionality")
    public List<String> getFunctionality() {
        return functionality;
    }

    public void setFunctionality(List<String> functionality) {
        this.functionality = functionality;
    }
}
