
package com.springtest.ingatmfinder.controller;

import com.springtest.ingatmfinder.model.ATMInfo;
import com.springtest.ingatmfinder.services.ATMInfoService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/")
public class   ATMFinderController {

    ATMInfoService atmInfoService;

    @Autowired
    public ATMFinderController(ATMInfoService atmInfoService) {
        this.atmInfoService = atmInfoService;
    }

    @GetMapping("atms/{city}")
    public ResponseEntity<List<ATMInfo>> getATMsForCity(@PathVariable final String city) {

        List<ATMInfo> atmInfos = null;

        if (Objects.nonNull(city) || !Strings.isEmpty(city))
            atmInfos = atmInfoService.getATMInfoForCity(city);

        return ResponseEntity.ok(atmInfos);
    }

}