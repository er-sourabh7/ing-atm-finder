package com.springtest.ingatmfinder.utils;

import java.io.*;

public class FileUtility {

    // readFromFile
    public String readFromFile(String fileName) {
        return "";
    }

    // writeToFile
    public String writeContentToFile(String fileName, InputStream inputStream) {
        BufferedReader bf = new BufferedReader(new InputStreamReader(inputStream));
        String content = writeContentToFile(fileName, bf);
        System.out.println("Content written to file");
        return content;
    }


    private String writeContentToFile(String fileName, BufferedReader bf) {
        StringBuilder stringBuilder = new StringBuilder();
        String line = "";
        try {
            FileWriter fileWriter = new FileWriter(new File(fileName));
            while ((line = bf.readLine()) != null) {
                stringBuilder.append(line);
            }
            fileWriter.write(stringBuilder.toString());
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            System.out.println("Error while operating on file -> " + fileName);
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }
}
