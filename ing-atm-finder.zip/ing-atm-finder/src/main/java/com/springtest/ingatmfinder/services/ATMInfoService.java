package com.springtest.ingatmfinder.services;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springtest.ingatmfinder.model.ATMInfo;
import com.springtest.ingatmfinder.utils.FileUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ATMInfoService {

    final String urlString = "https://www.ing.nl/api/locator/atms/";

    FileUtility fileUtility;

    @Autowired
    public ATMInfoService(FileUtility fileUtility){
        this.fileUtility = fileUtility;
    }

    public List<ATMInfo> getATMInfoForCity(String city) {
        // send request
        List<ATMInfo> atmInfos = sendRequestAndGetResult(city);

        return atmInfos;
    }

    private List<ATMInfo> sendRequestAndGetResult(String city) {
        // form the url request to the external API
        HttpURLConnection httpURLConnection = null;
        String outputFileName = "out.txt";
        List<ATMInfo> atmInfos = null;

        try {
            URL url = new URL(urlString);

            // send the request
            httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");

            if (httpURLConnection.getResponseCode() / 100 != 2) {
                throw new RuntimeException("Http request to " + url + " failed with response code " + httpURLConnection.getResponseCode());
            }

            //  To have the response saved in a file
            String content = fileUtility.writeContentToFile(outputFileName, httpURLConnection.getInputStream());
            httpURLConnection.disconnect();

            // map JSON to List of ATMInfo objects
            ObjectMapper objectMapper = new ObjectMapper();
            atmInfos = objectMapper.readValue(content.substring(content.indexOf("[")), new TypeReference<List<ATMInfo>>() {
            });

            // filter ATMInfos given the input City name
            atmInfos = atmInfos.parallelStream().filter(atm -> city.equalsIgnoreCase(atm.getAddress().getCity())).collect(Collectors.toList());
        } catch (MalformedURLException e) {
            System.out.println("Invalid URL");
        } catch (IOException e) {
            System.out.println("Error while executing the request");
        }
        return atmInfos;
    }
}
