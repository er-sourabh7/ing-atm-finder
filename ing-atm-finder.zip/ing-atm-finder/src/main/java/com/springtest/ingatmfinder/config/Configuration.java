package com.springtest.ingatmfinder.config;

import com.springtest.ingatmfinder.utils.FileUtility;
import org.springframework.context.annotation.Bean;

@org.springframework.context.annotation.Configuration
public class Configuration {

    @Bean
    public FileUtility getFileUtility() {
        return new FileUtility();
    }
}
