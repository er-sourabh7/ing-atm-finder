package com.springtest.ingatmfinder.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GeoLocation {

    private String lat;
    private String lng;

    public GeoLocation() {
    }

    public GeoLocation(String lat, String lng) {
        this.lat = lat;
        this.lng = lng;
    }

    @JsonProperty("lat")
    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    @JsonProperty("lng")
    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }
}
